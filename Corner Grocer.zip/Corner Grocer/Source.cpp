/*
    Corner Grocer - Grocery Tracking Program
    ----------------------------------------
    Purpose:
      Analyze daily sales data and report purchase frequencies.

    Features:
      1) Search for a specific item�s frequency
      2) Display all items with their purchase counts
      3) Show a text-based histogram of item frequencies
      4) Exit

    Files:
      - Input:  CS210_Project_Three_Input_File.txt
      - Output: frequency.dat (backup of computed frequencies; created at program start)

    Design Notes:
      - Encapsulated in a GroceryTracker class for clarity and maintainability.
      - Uses std::map<string,int> to count items (sorted output by key).
      - Includes simple input validation for menu choices.
      - Follows clean naming and inline comments for readability.

    Build:
      - Standard C++17 (or later). No external dependencies.

    Author: (Eduardo Romero)
*/

#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <limits>   // For std::numeric_limits
#include <iomanip>  // For formatting, if needed

class GroceryTracker {
private:
    std::map<std::string, int> freq_;     // Holds item -> count
    std::string inputFile_;
    std::string backupFile_;

    // Adds an item to the frequency map (case-sensitive by design).
    void addItem(const std::string& item) {
        if (!item.empty()) {
            ++freq_[item];
        }
    }

public:
    // Constructor lets you override file names if needed
    GroceryTracker(const std::string& inputFileName = "CS210_Project_Three_Input_File.txt",
        const std::string& backupFileName = "frequency.dat")
        : inputFile_(inputFileName), backupFile_(backupFileName) {}

    // Loads items from the input file; returns true on success.
    bool load() {
        std::ifstream fin(inputFile_);
        if (!fin.is_open()) {
            std::cerr << "Warning: Could not open input file '" << inputFile_
                << "'. The frequency map will be empty.\n";
            return false; // Not fatal for the program; user can still interact with empty data.
        }

        std::string item;
        // Reads whitespace-delimited tokens (typical for this assignment).
        // If your data uses multi-word items, adjust parsing accordingly.
        while (fin >> item) {
            addItem(item);
        }

        return true;
    }

    // Writes the frequency map to a backup file; returns true on success.
    bool writeBackup() const {
        std::ofstream fout(backupFile_);
        if (!fout.is_open()) {
            std::cerr << "Error: Could not open backup file '" << backupFile_ << "' for writing.\n";
            return false;
        }

        for (const auto& kv : freq_) {
            fout << kv.first << " " << kv.second << "\n";
        }

        return true;
    }

    // Returns frequency of a specific item; 0 if not found.
    int getFrequency(const std::string& item) const {
        auto it = freq_.find(item);
        return (it == freq_.end()) ? 0 : it->second;
    }

    // Prints all items with counts in alphabetical order (map order).
    void printAllFrequencies(std::ostream& out = std::cout) const {
        if (freq_.empty()) {
            out << "[No data loaded.]\n";
            return;
        }

        for (const auto& kv : freq_) {
            out << kv.first << " " << kv.second << "\n";
        }
    }

    // Prints a text-based histogram; symbol is '*' by default.
    void printHistogram(std::ostream& out = std::cout, char symbol = '*') const {
        if (freq_.empty()) {
            out << "[No data loaded.]\n";
            return;
        }

        for (const auto& kv : freq_) {
            out << kv.first << " ";
            for (int i = 0; i < kv.second; ++i) {
                out << symbol;
            }
            out << "\n";
        }
    }
};

// Utility: show the menu
void printMenu() {
    std::cout << "\n====== Corner Grocer: Grocery Tracking ======\n"
        << "1. Search for a specific item�s frequency\n"
        << "2. Display all items with purchase counts\n"
        << "3. Show histogram of item frequencies\n"
        << "4. Exit\n"
        << "Select an option (1-4): ";
}

// Utility: safely read an integer menu option
int readMenuChoice() {
    int choice;
    while (true) {
        if (std::cin >> choice) {
            if (choice >= 1 && choice <= 4) {
                return choice;
            }
            std::cout << "Please enter a number between 1 and 4: ";
        }
        else {
            // Clear bad state and discard invalid input
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Please enter a number between 1 and 4: ";
        }
    }
}

int main() {
    // Create the tracker and load data immediately
    GroceryTracker tracker;
    tracker.load();

    // Create the backup file (frequency.dat) at startup per requirements
    tracker.writeBackup();

    bool running = true;
    while (running) {
        printMenu();
        int choice = readMenuChoice();

        switch (choice) {
        case 1: {
            // Search for specific item frequency
            std::cout << "Enter the item name to search: ";
            std::string query;
            // Using >> reads one token (space-delimited). If your data uses multi-word items,
            // you can switch to std::getline(std::cin, query) with an extra ignore before it.
            std::cin >> query;

            int count = tracker.getFrequency(query);
            std::cout << query << " " << count << "\n";
            break;
        }
        case 2: {
            // Display all items with counts
            tracker.printAllFrequencies();
            break;
        }
        case 3: {
            // Display histogram using asterisks
            tracker.printHistogram(std::cout, '*');
            break;
        }
        case 4: {
            // Exit
            std::cout << "Exiting program. Goodbye!\n";
            running = false;
            break;
        }
        default:
            // Should never hit due to input validation, but kept for safety
            std::cout << "Unknown option. Please select 1-4.\n";
            break;
        }
    }

    return 0;
}
